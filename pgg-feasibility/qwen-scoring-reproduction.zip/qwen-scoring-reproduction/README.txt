Qwen saved-message scoring

This package scores existing public messages from Midway job 63458254, and it does not generate any new agent responses. The 15-round input comes from 1 neutral Qwen3-8B history-rule game, with its original ledger preserved in rounds.json.

Use Python 3.13 with torch 2.9.1 and transformers 5.20.2 for the recorded CPU environment. The analysis used exactly 1 CPU thread, with float32 model weights and deterministic algorithms enabled.

The scoring checkpoint is distilbert/distilgpt2 at revision 2290a62682d06624634c1f46a6ad5be0f47f38aa. Its files must already be in the Hugging Face cache, because score_messages.py runs with HF_HUB_OFFLINE enabled. Loading uncached weights will stop rather than request an API or download a different revision.

If the checkpoint is not cached, download that fixed revision separately with hf download distilbert/distilgpt2 --revision 2290a62682d06624634c1f46a6ad5be0f47f38aa before running the script. The model download does not use a paid inference API.

Run python score_messages.py from this extracted folder. The script evaluates each current message against exactly the preceding round's 4 public messages, then checks all 56 raw scores against expected_data.json. It also reproduces the quantity-masking diagnostic and writes reproduced_scores.csv.

The public metadata in protocol.json records the generating model revision and sampling settings. SHA256SUMS.json identifies the included source inputs, and the expected data retain full precision. The web figures use rounded labels without altering the stored results.

The optional mask replaces numerical strings and number words from zero through twenty with NUMBER in both context and target. This is an input diagnostic, and the original raw scores remain the primary measurement. No language threshold is defined or applied.

No paid API client is used, and running this script cannot submit a cluster job. The source game remains separate from any human controls or cross-model treatment comparison.
